# Tastengruppe

![MOAR KNÖPFE.](oredict:oc:materialButtonGroup)

Weil du *immer* zu viele Knöpfe hast. Lüg nicht! Wir Shift-Klicken das Tastenrezept immer und immer wieder. Die Gruppen werden um Bauen von [Tastaturen](../block/keyboard.md) verwendet.
