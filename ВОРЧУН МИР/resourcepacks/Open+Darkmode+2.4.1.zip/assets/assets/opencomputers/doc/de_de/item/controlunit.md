# Kontrolleinheit

![Mit eingebauter Cruising-Funktion.](oredict:oc:materialCU)

Hochstufiges Craftingitem in weiter entwickelten Schaltkreisen wie [CPUs](cpu1.md).
