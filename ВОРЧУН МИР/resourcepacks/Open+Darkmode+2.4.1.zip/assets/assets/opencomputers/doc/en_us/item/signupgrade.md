# Sign I/O

![I see the signs on the wall.](oredict:oc:signUpgrade)

This upgrade allows devices to interact with signs in the world. It allows reading the current message on the sign as well as changing the message on the sign (if permitted. 