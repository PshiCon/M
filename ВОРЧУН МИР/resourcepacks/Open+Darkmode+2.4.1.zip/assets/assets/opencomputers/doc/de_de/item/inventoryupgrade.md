# Inventar-Upgrade

![Wo legt es diesen ganzen Kram hin...](oredict:oc:inventoryUpgrade)

Das Inventar-Upgrade stellt Inventarslots für [Roboter](../block/robot.md) und [Drohnen](drone.md) bereit. Jedes Upgrade fügt 16 Inventarslots hinzu, bis zu einem Maximum von 64 Slots. Eine Drohne fügt 4 Slots pro Upgrade hinzu, bis zu einem Maximum von 8 Slots.

Ohne Inventar-Upgrade können diese Geräte keine Items aufheben.
