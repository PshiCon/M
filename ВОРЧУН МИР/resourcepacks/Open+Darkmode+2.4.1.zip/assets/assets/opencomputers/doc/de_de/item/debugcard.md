# Debugkarte

![Warte - Wenn ich... oooooh.](item:OpenComputers:item@73)

Die Debugkarte ist ein Nur-Kreativ-Item das ursprünglich entwickelt wurde, um einige Vorgänge zu vereinfachen in dem sie einige Prozesse automatisieren. Es hat seitdem eine Vielfalt an Zusatzfunktionen erhalten.

Ein Schleich-Rechtsklick bindet oder entbindet die Karte zum Anwender. Dies bedeutet, dass `runCommand` mit den Permissions des Anwenders anstatt der Standardpermissions von OpenComputers ausgeführt wird.
