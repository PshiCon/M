# Card

![Can't be read.](oredict:oc:materialCard)

Common crafting material for card components in OpenComputers (such as [graphics cards](graphicsCard1.md), [network cards](lanCard.md), etc).
