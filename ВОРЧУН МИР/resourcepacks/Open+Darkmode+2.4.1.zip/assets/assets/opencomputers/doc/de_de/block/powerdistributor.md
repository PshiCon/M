# Stromverteiler

![Power to the masses.](oredict:oc:powerDistributor)

Der Stromverteiler verteilt Energie in einem geteilten Energiespeicher (wie beispielsweise in einem [Kondensator](capacitor.md). Dadurch können verschiedene Subnetzwerke dieselbe Energiequelle verwenden ohne Komponenten sichtbar zu machen. Es balanciert die Energie in allen Subnetzwerken aus, sodass sie alle die selbe relative Menge an Energie haben.
