# Internetkarte

![Katzenvideos in 3, 2,....](oredict:oc:internetCard)

Internetkarten bieten [Computern](../general/computer.md) Internetzugriff. Einfache HTTP-Anfragen sind möglich, sowie einfache TCP-Client-Sockets die gelesen und beschrieben werden können.

Eine Internetkarte zu installieren fügt zudem einen Speicher hinzu, auf dem einige Internetprogramme installiert sind, wie das hoch- und herunterladen von Text zu/von pastebin sowie ein `wget`-Klon zum herunterladen von Dateien aus dem Internet.
