# Kartenbehälter

![Ich kann Karten haben!!](oredict:oc:cardContainer1)

Der Kartenbehälter ist ein Behälter-Upgrade für [Roboter](../block/robot.md) das es erlaubt, Karten in [Roboter](../block/robot.md) nach Bedarf einzusetzen oder zu entfernen. Die Stufe die eine Karte maximal haben darf gleicht der des Containers. Im Gegensatz zu normalen Upgrades ist die Komplexität das Doppelte seiner Stufe. Siehe [Komplexität](../block/robot.md).
