# Microchips

![Not the edible ones.](oredict:oc:circuitChip1)

Microchips are the bread and butter of electronic component crafting. They come in different tiers, for crafting different tiers of components. 
