# Internetz

![A website is a place where there's cobweb.](oredict:oc:materialInterweb)

Das Internetz ist eine grundlegende Komponente für alle Geräte die mit Hochdistanzkommunikation zusammenhängen. Es nutzt verrückte Mechaniken des Ends um Quantenlinienkommunikation zu ermöglichen. Wird vor allem in [Internetkarten](internetCard.md) und [verknüpften Karten](linkedCard.md) verwendet.
