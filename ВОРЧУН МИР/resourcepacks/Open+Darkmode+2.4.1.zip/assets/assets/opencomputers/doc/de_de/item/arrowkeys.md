# Pfeiltasten

![Sei nur froh, dass die nicht aus echten Pfeilen hergestellt werden..](oredict:oc:materialArrowKey)

Pfeiltasten sind nötig um [Tastaturen](../block/keyboard.md) zu bauen.
