# Raw Circuit Board

![Not sushi.](oredict:oc:materialCircuitBoardRaw)

Intermediary crafting material, used for crafting [circuit boards](circuitBoard.md) (or [printed circuit boards](printedCircuitBoard.md), depending on the recipe set being used).
