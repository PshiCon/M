# Bewegungssensor

![Nicht. Blinzeln.](oredict:oc:motionSensor)

Der Bewegungssensor erlaubt es [Computern](../general/computer.md) Bewegungen von lebenden Entities zu erkennen. Wenn die Geschwindigkeit eines Lebewesens einen Schwellenwert überschreitet wird ein Signal zum angeschlossenen Computer gesendet. Der Schwellwert kann mittels der Komponenten-API welche der Bewegungssensor bereitstellt verändert werden.

Die Bewegung wird nur erkannt, wenn sie in einem Radius von acht Blöcken um den Sensor geschieht und wenn eine direkte Sichtlinie besteht.
