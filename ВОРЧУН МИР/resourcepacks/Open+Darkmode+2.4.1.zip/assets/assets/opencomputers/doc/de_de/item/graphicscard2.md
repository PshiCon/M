#REDIRECT graphicsCard1.md
