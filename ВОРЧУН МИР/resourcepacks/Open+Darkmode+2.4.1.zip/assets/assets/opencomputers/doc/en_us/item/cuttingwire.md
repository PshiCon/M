# Cutting Wire

![Not a garrote. Honest.](oredict:oc:materialCuttingWire)

An item encountered when using hard-mode recipes, it is used for crafting [raw circuit boards](rawCircuitBoard.md). Very inefficiently.
