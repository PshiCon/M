# Messgerät

![Hat nichts mit Kirche zu tun.](oredict:oc:analyzer)

Das Messgerät ist ein nützliches Werkzeug um OpenComputers-Geräte auszulesen. Mittels eines Rechtsklickes (ggf. auch beim Schleichen) werden die Informationen in den Chatlog geschrieben. Darunter fallen grundlegende Dinge wie die Adresse von Komponenten, den Energiemassen im Subnetzwerk bis zu Informationen über einen Crash.

Eine weitere nützliche Funktion ist, dass STRG+Rechtsklick die Adresse einer Komponente in die Zwischenablage kopiert. Diese Information kann beispielsweise in ein Computerterminal kopiert werden.
