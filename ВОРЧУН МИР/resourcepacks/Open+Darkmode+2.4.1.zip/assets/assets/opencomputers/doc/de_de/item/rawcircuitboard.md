# Leiterplattenrohling

![Nicht Sushi.](oredict:oc:materialCircuitBoardRaw)

Zwischenprodukt beim Fertigen. Wird verwendet, um [Leiterplatten](circuitBoard.md) (oder [gedruckte Leiterplatten](printedCircuitBoard.md), je nach dem welches Recipe-Set verwendet wird) zu fertigen.
