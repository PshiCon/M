# Gedruckte Leiterplatte (PCB)

![AKA PCB](oredict:oc:materialCircuitBoardPrinted)

Die bedruckte Leiterplatte ist, neben dem [Transistor](transistor.md) eine der grundlegendsten Werkstoffe in OpenComputers. Es wird als Basis für viele Komponenten verwendet, wie [Karten](card.md) und eine große Anzahl an [Blöcken](../block/index.md).
