# Arrow Keys

![Just be grateful it's not made from arrows.](oredict:oc:materialArrowKey)

At the risk of repeating myself: it's a button sink. Because the button economy has seen some serious inflation in recent years. It is used as a component for building [keyboards](../block/keyboard.md).
