# Disc

![World. RIP Terry Pratchett.](oredict:oc:materialDisk)

Basic crafting component used in crafting storage media such as [floppies](floppy.md) and [hard drives](hdd1.md).
