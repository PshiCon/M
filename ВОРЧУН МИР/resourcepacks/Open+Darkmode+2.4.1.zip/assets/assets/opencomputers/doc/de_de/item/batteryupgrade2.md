#REDIRECT batteryUpgrade1.md
