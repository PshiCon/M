# Hologrammprojektor

![Is this the real life? Is this just fantasy?](oredict:oc:hologram1)

Der Hologrammprojektor ist ein 3D-Display, das bedeutet es stellt ein dreidimensionales Array von "Voxeln" bereit, die von einem Computer einzeln aktiviert oder deaktiviert können. Der Stufe-2-Projektor hat dieselbe Auflösung, unterstützt allerdings die Darstellung in drei verschiedenen Farben.

Hologramme können an ihrer vertikalen Achse rotiert werden, wenn sie mit einem [Schraubenschlüssel](../item/wrench.md) an ihrer Ober- oder Unterseite berührt werden. Dies erspart den Aufwand, dies softwareseitig zu realisieren. Hologramme können auch skaliert werden.
