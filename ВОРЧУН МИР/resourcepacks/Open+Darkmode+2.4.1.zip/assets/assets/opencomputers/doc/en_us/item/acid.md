# Acid

![Reflux?](oredict:oc:materialAcid)

This tasty [citation needed] concoction can be consumed if you ever feel the need for some... fun. Or ruining your digestive tract. Or both. It can also serve as ingredient in other, more useful items.

One of the main uses, however, is to remove [nanomachines](nanomachines.md) from your system, if you no longer want them in you. Drinking this is the only way of getting rid of them!

When using hard-mode recipes, it is used to etch [circuit boards](circuitBoard.md) before crafting [printed circuit boards](printedCircuitBoard.md).
