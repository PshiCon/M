# MFU

![You will never know the true meaning of this acronym.](oredict:oc:mfu)

This upgrade acts as a remote [adapter](../block/adapter.md). Click while sneaking onto any side of any block to bind it to a specific position. Then, place it into an adapter nearby (the range is very limited) and it will act as if the adapter was placed right next to the specific side you bound it to!

Keep in mind that keeping the remote adapter connection active uses energy.
